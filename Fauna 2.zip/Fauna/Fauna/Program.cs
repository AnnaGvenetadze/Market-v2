﻿namespace Fauna;

class Program
{
    static void Main(string[] args)
    {
        Animal animal = new Animal("Hamster");
        Console.WriteLine();
        Dog dog = new Dog();
        Console.WriteLine();
        Cat cat = new Cat();
        Console.WriteLine();
        SuperDog superDog = new SuperDog();
    }
}
