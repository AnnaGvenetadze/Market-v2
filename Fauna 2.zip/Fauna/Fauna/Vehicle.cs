﻿namespace Fauna;

public class Vehicle
{
    public Vehicle()
    {
        Console.ForegroundColor = ConsoleColor.Green;
        Console.WriteLine("Vehicle was created!");
        Console.ResetColor();
    }

    public void Transport()
    {
        Console.WriteLine("Vehicle is transporting");
    }
}